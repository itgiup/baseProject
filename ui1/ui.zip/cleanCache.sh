git rm --cached .idea
git rm -r --cached .
