npm run build 
firebase deploy --only hosting
./push.sh
# shutdown -f -s -t 0